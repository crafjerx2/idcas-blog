import loginPage from "./pages/loginPage"


describe('Login tests', () => {

  // Hooks
  beforeEach(() => {
    cy.visit('/login')
  })

  it('login successfully', () => {

   cy.fixture('users').then( user => {
    cy.login(user.email, user.password)
   })
     
    cy.get('.topImage').should('exist')
  })

  it('login - email empty', () => {
    loginPage.passwordInput().type('123456')
    loginPage.submit().click()

    loginPage.checkMessage('El email es obligatorio')
  })
  
  it('login - password empty', () => {
    loginPage.emailInput().type('test@test.com')
    loginPage.submit().click()

    loginPage.checkMessage('El password es obligatorio')
  })


})