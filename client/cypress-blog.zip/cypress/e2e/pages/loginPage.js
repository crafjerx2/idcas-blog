
const emailInput = () => {
  return cy.get('[type="email"]')
}

const passwordInput = () => {
  return cy.get('[type="password"]')
}

const submit = () => {
  return cy.get('.loginSubmit');
}

const checkMessage = message => {
  cy.get('.notification').should('have.text', message)
}

export default {
  emailInput,
  passwordInput,
  submit,
  checkMessage
}





