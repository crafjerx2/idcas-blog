

export const email = 'cpineda@idcas.edu.do'
export const password = '123456'


const User = {
  email,
  password
}

export default {
  email,
  password
};


